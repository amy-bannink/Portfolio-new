package mastermind;

import java.util.Random;
import java.util.Scanner;

public class Mastermind_v3
{

    public static void main(String[] args)
    {
		
	
//	Variabelen declareren en initialiseren
	boolean singlePlayer = true;
	boolean validAnswer = false;
	boolean exitGame = false;
	int hintsLeft = 0;
	String giveHint;

//	Vragen aan speler welke game mode hij/zij wilt spelen en antwoord opslaan in een string
	System.out.println("Would you like to play single player or multiplayer mode? Type 1 for single player or 2 for multiplayer and press enter: ");
	Scanner input = new Scanner(System.in);
	String gameMode = input.nextLine();
	
	
//	Zorgen dat het antwoord geldig is en op basis van het antwoord de boolean singlePlayer op true of false zetten
	while (validAnswer != true) {
		if (gameMode.equals("1")) {
		    singlePlayer = true;
		    validAnswer = true;
		} else if (gameMode.equals("2")) {
		    singlePlayer = false;
		    validAnswer = true;
		} else {
//		    Zolang het antwoord niet geldig is blijft er gevraagd worden aan de speler om een antwoord te geven. Dit antwoord wordt opgeslagen om vervolgens weer te worden gecheckt
			System.out.println("Invalid input, please try again. Type 1 for single player or 2 for multiplayer and press enter: ");
			gameMode = input.nextLine();
		}
	}
	
//	De string array van de geheime code wordt gedeclareerd en de string array van de speler's antwoorden wordt gedeclareerd
	String [] guess = new String[4];
	String [] position = new String[4];
	
//	De round, de zwarte pionnen en de witte pionnen worden gedeclareerd en geïnitaliseerd met startwaarde 0
	Integer round = 0;
	Integer black = 0;
	Integer white = 0;
	
//	SinglePlayer mode start hier
	if (singlePlayer == true) {
//	    Array met alle mogelijke kleuren
	    	String [] colors = {"yellow", "green", "orange", "red", "blue", "purple"};	
//	    	m.b.v. Random wordt er een random getal gekozen die valt binnen de lengte van de array colors
		Random random = new Random();
		int index = random.nextInt(colors.length);	

//		Vier keer wordt een nieuw random gekozen getal gebruikt om één van de mogelijke kleuren in de position array te plaatsen. Dit is de geheime kleurencode
		for (round = 0; round < 4; round++) {
		    index = random.nextInt(colors.length);
		    position[round] = colors[index];
//		    Een print statement, handig voor bij het testen, maar tijdens het spel staat deze als commentaar
//		    System.out.print(position[round]);
		}
//		round wordt weer teruggezet op 0 om de rondes van het spel bij te houden
		round = 0;
		
//		Alle mogelijke levels worden gedeclareerd en geïnitaliseerd met startwaarde false
		boolean levelEasy = false;
		boolean levelMedium = false;
		boolean levelHard = false;
		
//		Boolean die checkt of het antwoord geldig is wordt weer teruggezet op false om opnieuw te kunnen gebruiken en de speler wordt gevraagd het gewenste level in te voeren
		validAnswer = false;
		System.out.println("Which level do you want to play? Type easy, medium or hard to make your choice en press enter: ");
		String gameLevel = input.next();
		
//		Het antwoord van de speler wordt vergeleken met de opties en het gekozen level wordt op true gezet. Op basis hiervan krijgt de speler een bepaalde hoeveelheid hints. ValidAnswer wordt bij een geldig antwoord op true gezet. Als er geen geldig antwoord is gegeven, wordt de speler gevraagd het opnieuw te proberen en wordt het nieuwe antwoord opgeslagen om vervolgens verifiëren
		while (validAnswer != true) {
		    if (gameLevel.equals("easy")) {
			levelEasy = true;
			hintsLeft = 2;
			validAnswer = true;
		    } else if(gameLevel.equals("medium")) {
			levelMedium = true;
			hintsLeft = 1;
			validAnswer = true;
		    } else if (gameLevel.equals("hard")) {
			levelHard= true;
			hintsLeft = 0;
			validAnswer = true;
		    } else {
			System.out.println("Invalid input, please try again. Type easy, medium or hard to make your choice en press enter: ");
			gameLevel = input.next();
		    }
		}
		
//		validAnswer wordt teruggezet naar false zodat deze variabele opnieuw gebruikt kan worden de volgende keer dat er een antwoord geverifieerd moet worden
		validAnswer = false;
		
//		Hier start levelEasy in singlePlayer mode
		if (levelEasy == true && levelMedium == false && levelHard == false) {
		    System.out.println("You chose level easy. You have 12 rounds to crack the color code and you get 2 hints. Enjoy playing!");
//		    Speler krijgt 12 rondes in levelEasy. Zolang de kleurencode nog niet is gekraakt en de speler nog rondes heeft, worden de spelrondes binnen deze while loop herhaalt
		    while (round < 12 & black != 4) {
//			De zwarte en witte pionnen worden op 0 gezet, zodat de speler per ronde kan zien hoeveel hij/zij er goed heeft in die ronde. Round wordt geüpdate met +1
			    black = 0;
			    white = 0;
			    round++;
//			    De speler wordt per pion gevraagd welke kleur hij/zij wil gokken
			    System.out.println("Round " + round + "/12. Guess the color of pawn 1. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
//			    De gegokte kleur wordt opgeslagen in array guess
			    guess[0] = input.next();
//			    Speler krijgt de mogelijkheid om het spel te stoppen door 0000 in te typen
			    if (guess[0].equals("0000")) {
//				Als de speler heeft ingevoerd te willen stoppen met het spel, wordt exitGame op true gezet zodat er buiten de while loop een passend bericht uitgeprint kan worden
				    exitGame = true;
				    break;
				} 
			    System.out.println("Round " + round + "/12. Guess the color of pawn 2. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[1] = input.next();
			    if (guess[1].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/12. Guess the color of pawn 3. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[2] = input.next();
			    if (guess[2].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/12. Guess the color of pawn 4. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[3] = input.next();
			    if (guess[3].equals("0000")) {
				    exitGame = true;
				    break;
				}
//			    Het antwoord van de speler wordt vergeleken met de geheime code. Het zijn beide strings dus hiervoor wordt .equals gebruikt. Eerst wordt gecheckt of de juiste kleur op de juiste plek voorkomt en een zwarte pion mag krijgen. Wanneer dat niet het geval is wordt er gecheckt of de kleur ergens anders voorkomt en een witte pion moet krijgen.
			    if (position[0].equals(guess[0])) {
				black++;
			    } else if(position[0].equals(guess[1])|| position[0].equals(guess[2]) || position[0].equals(guess[3])) {
				white++;
			    } 
			    if (position[1].equals(guess[1])) {
			  		black++;
			  	    } else if(position[1].equals(guess[0]) || position[1].equals(guess[2]) || position[1].equals(guess[3])) {
			  		white++;
			  	    } 
			    if (position[2].equals(guess[2])) {
			  		black++;
			  	    } else if(position[2].equals(guess[0]) || position[2].equals(guess[1]) || position[2].equals(guess[3])) {
			  		white++;
			  	    } 
			    if (position[3].equals(guess[3])) {
			  		black++;
			  	    } else if(position[3].equals(guess[0]) || position[3].equals(guess[1]) || position[3].equals(guess[2])) {
			  		white++;
			  	    } 
//			    Het aantal zwarte en witte pionnen wordt aan de speler getoond samen met zijn/haar gegokte kleuren voor een handig overzicht.
			    System.out.print(white + " white pawn(s). " + black + " black pawn(s). ");
			    System.out.println("You guessed: " + guess[0] + " " + guess[1] + " " + guess[2] + " " + guess[3]);
//			    Er wordt gecheckt of de kleurencode is gekraakt. Zo ja, dan wordt het aantal rondes op 12 gezet en uitgeprint dat de speler de code heeft gekraakt
			    if (black == 4) {
				System.out.print("You cracked the color code! ");
				round = 12;
			    } else {
//				Als de kleurencode nog niet is gekraakt wordt er gecheckt of de speler nog hints over heeft en gevraagd of de speler een hint wilt
				if (hintsLeft>0) {
					System.out.println("You have " + hintsLeft + " hints left. Type 'hint' to receive one or 'next' to go to the next round: ");
					giveHint = input.next();
					    validAnswer = false;
//					Er wordt gecheckt of de speler een valide antwoord geeft
					while (validAnswer != true) {
//					    Als de speler 'hint' heeft ingevoerd, wordt er een hint gegeven, hintsLeft wordt geüpdate en validAnswer wordt op true gezet om te bevestigen dat er een geldig antwoord is gegeven
					    if (giveHint.equals("hint")) {
						System.out.println("HINT: pawn " + (hintsLeft + 1) + " is " + position[hintsLeft] + ".");
        					hintsLeft--;
        					validAnswer = true;
//        					Als de speler 'next' heeft ingevoerd, wordt er uitgeprint dat de volgende ronde begint en validAnswer wordt op true gezet om te bevestigen dat er een geldig antwoord is gegeven
					    }else if(giveHint.equals("next")) {
						    System.out.println("Next round: ");
						    validAnswer = true;
//						    Als de speler iets heeft ingevoerd wat niet overeenkomt met de geldige opties, wordt er gevraagd opnieuw een antwoord te geven. validAnswer blijft op false staan en het nieuwe antwoord van de speler wordt weer opgeslagen om te worden vergeleken met de geldige antwoord opties
						} else {
						    System.out.println("Invalid input, please try again. Type 'hint' or 'next': ");
							giveHint = input.next();
						}
					}
				} 
//				Als de speler geen hints meer heeft, wordt er niks gevraagd en wordt er alleen getoond dat de volgende ronde start 
				else {
				    System.out.println("Next round.");
				}
				
			    }
//			    validAnswer wordt weer teruggezet naar false zodat deze variabele opnieuw gebruikt kan worden om het antwoord van de speler te verifiëren in de volgende ronde
			    validAnswer = false;
		}
//		    Dit is buiten de while loop. Er wordt gecheckt waarom het spel uit de while loop is. De speler kan hebben gewonnen, de speler kan hebben gekozen om het spel te stoppen en de speler kan hebben verloren
			if (black == 4) {
			    System.out.println("Congratulations!");
			} else if(exitGame == true) {
			    System.out.println("You chose to quit the game");
			}
			else {
			    System.out.println("You could not crack the color code within 12 rounds. You lost!");
			}
		} 
		
//		Hier start levelMedium in singlePlayer mode
		else if (levelMedium == true && levelEasy == false && levelHard == false) {
		    System.out.println("You chose level medium. You have 11 rounds to crack the color code and you get 1 hint. Enjoy playing!");
//		    Speler krijgt in levelMedium 11 rondes
		    while (round < 11 & black != 4) {
			    black = 0;
			    white = 0;
			    round++;
			    System.out.println("Round " + round + "/11. Guess the color of pawn 1. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[0] = input.next();
			    if (guess[0].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println(" Round " + round + "/11. Guess the color of pawn 2. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[1] = input.next();
			    if (guess[1].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println(" Round " + round + "/11. Guess the color of pawn 3. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[2] = input.next();
			    if (guess[2].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println(" Round " + round + "/11. Guess the color of pawn 4. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[3] = input.next();
			    if (guess[3].equals("0000")) {
				    exitGame = true;
				    break;
				}			    
			    if (position[0].equals(guess[0])) {
				black++;
			    } else if(position[0].equals(guess[1]) || position[0].equals(guess[2]) || position[0].equals(guess[3])) {
				white++;
			    } 
			    if (position[1].equals(guess[1])) {
			  		black++;
			  	    } else if(position[1].equals(guess[0]) || position[1].equals(guess[2]) || position[1].equals(guess[3])) {
			  		white++;
			  	    } 
			    if (position[2].equals(guess[2])) {
			  		black++;
			  	    } else if(position[2].equals(guess[0]) || position[2].equals(guess[1]) || position[2].equals(guess[3])) {
			  		white++;
			  	    } 
			    if (position[3].equals(guess[3])) {
			  		black++;
			  	    } else if(position[3].equals(guess[0]) || position[3].equals(guess[1]) || position[3].equals(guess[2])) {
			  		white++;
			  	    } 
			    System.out.print(white + " white pawn(s). " + black + " black pawn(s). ");
			    System.out.println("You guessed: " + guess[0] + " " + guess[1] + " " + guess[2] + " " + guess[3]);
			    if (black == 4) {
				System.out.print("You cracked the color code! ");
				round = 10;
			    } else {
				System.out.println("You guessed: " + guess[0] + " " + guess[1] + " " + guess[2] + " " + guess[3]);
				if (hintsLeft>0) {
					System.out.println("You have " + hintsLeft + " hints left. Type 'hint' to receive one or 'next' to go to the next round: ");
					giveHint = input.next();
					    validAnswer = false;

					while (validAnswer != true) {
					    if (giveHint.equals("hint")) {
						System.out.println("HINT: pawn " + (hintsLeft + 1) + " is " + position[hintsLeft] + ".");
        					hintsLeft--;
        					validAnswer = true;
					    }else if(giveHint.equals("next")) {
						    System.out.println("Next round: ");
						    validAnswer = true;
						} else {
						    System.out.println("Invalid input, please try again. Type 'hint' or 'next': ");
							giveHint = input.next();
						}
					}
				} else {
				    System.out.println("Next round.");
				}
				
			    }
			    validAnswer = false;
		}
			if (black == 4) {
			    System.out.println("Congratulations!");
			} else if(exitGame == true) {
			    System.out.println("You chose to quit the game");
			}
			else {
			    System.out.println("You could not crack the color code within 11 rounds. You lost!");
			}
		}
//		Hier start levelHard in singlePlayer mode
		else if (levelHard == true && levelEasy == false && levelMedium == false) {
		    System.out.println("You chose level hard. You have 10 rounds to crack the color code and you get 0 hints. Enjoy playing!");
//		    Speler krijgt in level hard 10 rondes
		    while (round < 10 & black != 4) {
			    black = 0;
			    white = 0;
			    round++;
			    System.out.println("Round " + round + "/10. Guess the color of pawn 1. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[0] = input.next();
			    if (guess[0].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/10. Guess the color of pawn 2. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[1] = input.next();
			    if (guess[1].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/10. Guess the color of pawn 3. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[2] = input.next();
			    if (guess[2].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/10. Guess the color of pawn 4. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[3] = input.next();
			    if (guess[3].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    if (position[0].equals(guess[0])) {
				black++;
			    } else if(position[0].equals(guess[1]) || position[0].equals(guess[2]) || position[0].equals(guess[3])) {
				white++;
			    } 
			    if (position[1].equals(guess[1])) {
			  		black++;
			  	    } else if(position[1].equals(guess[0]) || position[1].equals(guess[2]) || position[1].equals(guess[3])) {
			  		white++;
			  	    } 
			    if (position[2].equals(guess[2])) {
			  		black++;
			  	    } else if(position[2].equals(guess[0]) || position[2].equals(guess[1]) || position[2].equals(guess[3])) {
			  		white++;
			  	    } 
			    if (position[3].equals(guess[3])) {
			  		black++;
			  	    } else if(position[3].equals(guess[0]) || position[3].equals(guess[1]) || position[3].equals(guess[2])) {
			  		white++;
			  	    } 
			    System.out.print(white + " white pawn(s). " + black + " black pawn(s). ");
			    System.out.println("You guessed: " + guess[0] + " " + guess[1] + " " + guess[2] + " " + guess[3]);
			    if (black == 4) {
				System.out.print("You cracked the color code! ");
				round = 10;
			    } else{
				System.out.println("You guessed: " + guess[0] + " " + guess[1] + " " + guess[2] + " " + guess[3]);
				if (hintsLeft>0) {
					System.out.println("You have " + hintsLeft + " hints left. Type 'hint' to receive one or 'next' to go to the next round: ");
					giveHint = input.next();
					    validAnswer = false;

					while (validAnswer != true) {
					    if (giveHint.equals("hint")) {
						System.out.println("HINT: pawn " + (hintsLeft + 1) + " is " + position[hintsLeft] + ".");
        					hintsLeft--;
        					validAnswer = true;
					    }else if(giveHint.equals("next")) {
						    System.out.println("Next round: ");
						    validAnswer = true;
						} else {
						    System.out.println("Invalid input, please try again. Type 'hint' or 'next': ");
							giveHint = input.next();
						}
					}
				} else {
				    System.out.println("Next round.");
				}
				
			    }
			    validAnswer = false;
		}
			if (black == 4) {
			    System.out.println("Congratulations!");
			} else if(exitGame == true) {
			    System.out.println("You chose to quit the game");
			}else {
			    System.out.println("You could not crack the color code within 10 rounds. You lost!");
			}
		} else {
		    System.out.println("Something went wrong. Please restart the game.");
		}
		
		

	} 
//	Hier start multiPlayer mode
	else if (singlePlayer == false) {
	    validAnswer = false;
//	    Speler 1 moet een kleur invullen voor pion 1
	    System.out.println("Player 1, enter the color of pawn 1. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
		position[0] = input.next();
//		Er wordt gecheckt of het antwoord valide is
	    while(validAnswer != true) {
		if(position[0].equals("purple") || position[0].equals("blue") || position[0].equals("yellow") || position[0].equals("green") || position[0].equals("orange") || position[0].equals("red")) {
		    validAnswer = true;
		} else {
		    validAnswer = false;
		    System.out.println("Invalid input, try again. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			position[0] = input.next();
		}
	    }
		validAnswer = false;
//		Speler 1 moet een kleur invullen voor pion 2
		System.out.println("Player 1, enter the color of pawn 2. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
		position[1] = input.next();
		while(validAnswer != true) {
			if(position[1].equals("purple") || position[1].equals("blue") || position[1].equals("yellow") || position[1].equals("green") || position[1].equals("orange") || position[1].equals("red")) {
			    validAnswer = true;
			} else {
			    System.out.println("Invalid input, try again. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
				position[1] = input.next();
			}
		}
		validAnswer = false;	
//		Speler 1 moet een kleur invullen voor pion 3
		System.out.println("Player 1, enter the color of pawn 3. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
		position[2] = input.next();
		while(validAnswer != true) {
			if(position[2].equals("purple") || position[2].equals("blue") || position[2].equals("yellow") || position[2].equals("green") || position[2].equals("orange") || position[2].equals("red")) {
			    validAnswer = true;
			} else {
			    System.out.println("Invalid input, try again. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
				position[2] = input.next();
			}
		}
		validAnswer = false;
//		Speler 1 moet een kleur invullen voor pion 4
		System.out.println("Player 1, enter the color of pawn 4. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
		position[3] = input.next();
		while(validAnswer != true) {
			if(position[3].equals("purple") || position[3].equals("blue") || position[3].equals("yellow") || position[3].equals("green") || position[3].equals("orange") || position[3].equals("red")) {
			    validAnswer = true;
			} else {
			    System.out.println("Invalid input, try again. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
				position[3] = input.next();
			}
		}
		
//		De verschillende levels worden weer teruggezet op false
		boolean levelEasy = false;
		boolean levelMedium = false;
		boolean levelHard = false;
		validAnswer = false;
		
//		Er wordt een afbeelding uitgeprint zodat speler 2 niet kan zien wat speler 1 heeft ingevuld als kleurencode
		System.out.println("Player 1, your answers have been saved.");
		System.out.println("Cleaning the screen for player 2.......");
		System.out.println("________________¶¶¶¶¶_________¶¶¶¶¶\r\n"
			+ "_______________¶4_4_4¶¶_____¶¶4_4_4¶\r\n"
			+ "______________¶4_4_4_4_¶___¶_4_4_4_4¶\r\n"
			+ "______________¶_4_4_4_4_¶_¶_4_4_4_4_¶\r\n"
			+ "_______¶¶¶¶___¶4_4_4_4_4_¶_4_4_4_4_4¶____¶¶¶\r\n"
			+ "_____¶¶4_4¶¶¶__¶4_4_4_4_4_4_4_4_4_4¶__¶¶¶4_4¶¶\r\n"
			+ "_____¶4_4_4_4¶¶4_4_4_4_4_4_4_4_4_4_4¶¶4_4_4_4_¶\r\n"
			+ "_____¶_4_4_4__4_4_4_4_4_4_4_4_4_4_4_4__4_4_4_¶\r\n"
			+ "______¶_4_4_44_4_4_4_4_4_4_4_4_4_4_4_44_4_4_¶¶\r\n"
			+ "_______¶¶4_4__4_4_4_4_4_4_4_4_4_4_4_4__4_4_¶\r\n"
			+ "_________¶¶_44_4_4_4_4¶¶¶¶¶¶¶4_4_4_4_44_4¶¶\r\n"
			+ "_____¶¶¶¶4_4__4_4_4_¶¶0000000¶¶_4_4_4__4¶\r\n"
			+ "_¶¶¶¶_4_4_4_44_4_4_¶00000000000¶_4_4_44_4¶¶¶¶¶\r\n"
			+ "¶4_4_4_4_4_4__4_4_¶0000000000000¶_4_4__4_4_4_4¶¶¶\r\n"
			+ "¶_4_4_4_4_4_44_4_4¶0000000000000¶4_4_44_4_4_4_4_4¶\r\n"
			+ "_¶¶4_4_4_4_4__4_4_¶0000000000000¶_4_4__4_4_4_4_4_¶\r\n"
			+ "___¶¶¶¶¶¶_4_44_4_4_¶00000000000¶_4_4_44_4_4_4_4¶¶\r\n"
			+ "_________¶_4__4_4_4_¶¶0000000¶¶_4_4_4__4_¶¶¶¶¶¶\r\n"
			+ "________¶_4_44_4_4_4_4¶¶¶¶¶¶¶4_4_4_4_44_¶\r\n"
			+ "______¶¶_4_4__4_4_4_4_4_4_4_4_4_4_4_4__4_¶¶\r\n"
			+ "_____¶4_4_4_44_4_4_4_4_4_4_4_4_4_4_4_44_4_4¶\r\n"
			+ "____¶4_4_4_4__4_4_4_4_4_4_4_4_4_4_4_4__4_4_4¶\r\n"
			+ "____¶_4_4_4_¶4_4_4_4_4_4_4_4_4_4_4_4_44_4_4_¶\r\n"
			+ "____¶4_4_4_¶__4_4_4_4_4_4_4_4_4_4_4¶¶¶_4_4_4¶\r\n"
			+ "_____¶¶¶¶¶¶__4_4_4_4_4_4¶4_4_4_4_4_¶__¶¶¶¶¶¶\r\n"
			+ "______________4_4_4_4_4¶$¶4_4_4_4_4¶\r\n"
			+ "_____________¶_4_4_4_4¶$$$¶4_4_4_4_¶\r\n"
			+ "_____________¶4_4_4_¶¶_$$$_¶¶_4_4_¶\r\n"
			+ "______________¶¶¶¶¶¶___$$$___¶¶¶¶¶\r\n"
			+ "_______________________$$$\r\n"
			+ "_______________________$$$\r\n"
			+ "_______________________$$$\r\n"
			+ "_______________________$$$\r\n"
			+ "_¶¶¶¶¶_________________$$$________________¶¶¶¶¶¶\r\n"
			+ "¶77777¶¶¶¶_____________$$$_____________¶¶¶777777¶\r\n"
			+ "¶777777777¶¶___________$$$___________¶¶777777777¶\r\n"
			+ "¶77777777777¶¶_________$$$_________¶¶77777777777¶\r\n"
			+ "_¶777777777777¶¶_______$$$_______¶¶77777777777¶¶\r\n"
			+ "__¶¶777777777777¶¶_____$$$_____¶¶777777777777¶\r\n"
			+ "____¶7777777777777¶¶___$$$___¶¶7777777777777¶\r\n"
			+ "_____¶¶7777777777777¶__$$$_¶¶7777777777777¶¶\r\n"
			+ "_______¶¶777777777777¶¶$$$¶7777777777777¶¶\r\n"
			+ "_________¶¶¶7777777777¶¶¶¶¶777777777777¶\r\n"
			+ "____________¶7777777777777777777777777¶\r\n"
			+ "_____________¶¶¶777777777777777777¶¶¶¶\r\n"
			+ "________________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶\r\n"
			+ "");

//		Speler 2 kiest zijn/haar gewenste level
		System.out.println("Player 2, which level do you want to play? Type easy, medium or hard to make your choice en press enter: ");
		String gameLevel = input.next();
		
//		Het antwoord wordt gecheckt op geldigheid en het gekozen level wordt op true gezet
		while (validAnswer != true) {
		    if (gameLevel.equals("easy")) {
			levelEasy = true;
			hintsLeft = 2;
			validAnswer = true;
		    } else if(gameLevel.equals("medium")) {
			levelMedium = true;
			hintsLeft = 1;
			validAnswer = true;
		    } else if (gameLevel.equals("hard")) {
			levelHard= true;
			hintsLeft = 0;
			validAnswer = true;
		    } else {
			System.out.println("Invalid input, please try again. Type easy, medium or hard to make your choice en press enter: ");
			gameLevel = input.next();
		    }
		}
		
//		Hier start levelEasy in multiPlayer mode
		if(levelEasy == true && levelMedium == false && levelHard == false) {
		    System.out.println("You chose level easy. You have 12 rounds to crack the color code and you get 2 hints. Enjoy playing!");
		    while (round < 12) {
			    black = 0;
			    white = 0;
			    round++;
			    System.out.println("Round " + round + "/12. Player 2, guess the color of pawn 1. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[0] = input.next();
			    if (guess[0].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/12. Player 2, guess the color of pawn 2. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[1] = input.next();
			    if (guess[1].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/12. Player 2, guess the color of pawn 3. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[2] = input.next();
			    if (guess[2].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/12. Player 2, guess the color of pawn 4. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[3] = input.next();
			    if (guess[3].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    if (position[0].equals(guess[0])) {
				black++;
			    } else if (position[0].equals(guess[1])||position[0].equals(guess[2])||position[0].equals(guess[3])) {
					white++;
				}
			    if (position[1].equals(guess[1])) {
		  		black++;
		  	    } else if(position[1].equals(guess[0]) || position[1].equals(guess[2]) || position[1].equals(guess[3])) {
		  		white++;
		  	    } 
			    if (position[2].equals(guess[2])) {
		  		black++;
		  	    } else if(position[2].equals(guess[0]) || position[2].equals(guess[1]) || position[2].equals(guess[3])) {
		  		white++;
		  	    } 
			    if (position[3].equals(guess[3])) {
		  		black++;
		  	    } else if(position[3].equals(guess[0]) || position[3].equals(guess[1]) || position[3].equals(guess[2])) {
		  		white++;
		  	    } 
			    
			    System.out.print(white + " white pawn(s). " + black + " black pawn(s). ");
			    System.out.println("You guessed: " + guess[0] + " " + guess[1] + " " + guess[2] + " " + guess[3]);

	        	    if (black == 4) {
	        		System.out.print("You cracked the color code! ");
	        		round = 12;
	        	    } else {
				if (hintsLeft>0) {
					System.out.println("You have " + hintsLeft + " hints left. Type 'hint' to receive one or 'next' to go to the next round: ");
					giveHint = input.next();
					    validAnswer = false;

					while (validAnswer != true) {
					    if (giveHint.equals("hint")) {
						System.out.println("HINT: pawn " + (hintsLeft + 1) + " is " + position[hintsLeft] + ".");
        					hintsLeft--;
        					validAnswer = true;
					    }else if(giveHint.equals("next")) {
						    System.out.println("Next round: ");
						    validAnswer = true;
						} else {
						    System.out.println("Invalid input, please try again. Type 'hint' or 'next': ");
							giveHint = input.next();
						}
					}
				} else {
				    System.out.println("Next round.");
				}
				
			    }
			    validAnswer = false;
		}
		if (black == 4) {
		    System.out.println("Congratulations!");
		} else if(exitGame == true) {
		    System.out.println("You chose to quit the game");
		}else {
		    System.out.println("You could not crack the color code within 12 rounds. You lost!");
		}
		} 
//		Hier start levelMedium in multiPlayer mode
		else if (levelMedium == true && levelEasy == false && levelHard == false) {
		    System.out.println("You chose level medium. You have 11 rounds to crack the color code and you get 1 hint. Enjoy playing!");
		    while (round < 11) {
			    black = 0;
			    white = 0;
			    round++;
			    System.out.println("Round " + round + "/11. Player 2, guess the color of pawn 1. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[0] = input.next();
			    if (guess[0].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/11. Player 2, guess the color of pawn 2. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[1] = input.next();
			    if (guess[1].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/11. Player 2, guess the color of pawn 3. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[2] = input.next();
			    if (guess[2].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/11. Player 2, guess the color of pawn 4. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[3] = input.next();
			    if (guess[3].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    if (position[0].equals(guess[0])) {
				black++;
			    } else if (position[0].equals(guess[1])||position[0].equals(guess[2])||position[0].equals(guess[3])) {
					white++;
				}
			    if (position[1].equals(guess[1])) {
		  		black++;
		  	    } else if(position[1].equals(guess[0]) || position[1].equals(guess[2]) || position[1].equals(guess[3])) {
		  		white++;
		  	    } 
			    if (position[2].equals(guess[2])) {
		  		black++;
		  	    } else if(position[2].equals(guess[0]) || position[2].equals(guess[1]) || position[2].equals(guess[3])) {
		  		white++;
		  	    } 
			    if (position[3].equals(guess[3])) {
		  		black++;
		  	    } else if(position[3].equals(guess[0]) || position[3].equals(guess[1]) || position[3].equals(guess[2])) {
		  		white++;
		  	    } 
			    
			    System.out.print(white + " white pawn(s). " + black + " black pawn(s). ");
	        	    if (black == 4) {
	        		System.out.print("You cracked the color code! ");
	        		round = 11;
	        	    } else {
	        		System.out.println("You guessed: " + guess[0] + " " + guess[1] + " " + guess[2] + " " + guess[3]);
	        	    }
		}
		if (black == 4) {
		    System.out.println("Congratulations!");
		} else if(exitGame == true) {
		    System.out.println("You chose to quit the game");
		}else {
		    System.out.println("You could not crack the color code within 11 rounds. You lost!");
		}
		    
		    } 
//		Hier start levelHard in multiplayerMode
		else if (levelHard == true && levelEasy == false && levelMedium == false) {
		    System.out.println("You chose level Hard. You have 10 rounds to crack the color code and you get 0 hints. Enjoy playing!");
		    while (round < 10) {
			    black = 0;
			    white = 0;
			    round++;
			    System.out.println("Round " + round + "/10. Player 2, guess the color of pawn 1. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[0] = input.next();
			    if (guess[0].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/10. Player 2, guess the color of pawn 2. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[1] = input.next();
			    if (guess[1].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/10. Player 2, guess the color of pawn 3. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[2] = input.next();
			    if (guess[2].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    System.out.println("Round " + round + "/10. Player 2, guess the color of pawn 4. Make your choice between: purple, blue, yellow, green, orange, red and press enter: ");
			    System.out.println("(Or type '0000' if you want to quit the game)");
			    guess[3] = input.next();
			    if (guess[3].equals("0000")) {
				    exitGame = true;
				    break;
				}
			    
			    if (position[0].equals(guess[0])) {
				black++;
			    } else if (position[0].equals(guess[1])||position[0].equals(guess[2])||position[0].equals(guess[3])) {
					white++;
				}
			    if (position[1].equals(guess[1])) {
		  		black++;
		  	    } else if(position[1].equals(guess[0]) || position[1].equals(guess[2]) || position[1].equals(guess[3])) {
		  		white++;
		  	    } 
			    if (position[2].equals(guess[2])) {
		  		black++;
		  	    } else if(position[2].equals(guess[0]) || position[2].equals(guess[1]) || position[2].equals(guess[3])) {
		  		white++;
		  	    } 
			    if (position[3].equals(guess[3])) {
		  		black++;
		  	    } else if(position[3].equals(guess[0]) || position[3].equals(guess[1]) || position[3].equals(guess[2])) {
		  		white++;
		  	    } 
			    
			    System.out.print(white + " white pawn(s). " + black + " black pawn(s). ");
	        		System.out.println("You guessed: " + guess[0] + " " + guess[1] + " " + guess[2] + " " + guess[3]);

	        	    if (black == 4) {
	        		System.out.print("You cracked the color code! ");
	        		round = 10;
	        	    } else {
				if (hintsLeft>0) {
					System.out.println("You have " + hintsLeft + " hints left. Type 'hint' to receive one or 'next' to go to the next round: ");
					giveHint = input.next();
					    validAnswer = false;

					while (validAnswer != true) {
					    if (giveHint.equals("hint")) {
						System.out.println("HINT: pawn " + (hintsLeft + 1) + " is " + position[hintsLeft] + ".");
        					hintsLeft--;
        					validAnswer = true;
					    }else if(giveHint.equals("next")) {
						    System.out.println("Next round: ");
						    validAnswer = true;
						} else {
						    System.out.println("Invalid input, please try again. Type 'hint' or 'next': ");
							giveHint = input.next();
						}
					}
				} else {
				    System.out.println("Next round.");
				}
				
			    }
			    validAnswer = false;
		}
		if (black == 4) {
		    System.out.println("Congratulations!");
		} else if(exitGame == true) {
		    System.out.println("You chose to quit the game");
		}else {
		    System.out.println("You could not crack the color code within 10 rounds. You lost!");
		}
		    
		    }else {
			    System.out.println("Something went wrong. Please restart the game.");
			}
	}
	
    }
	
		}
