package mastermind2;

public class Mastermind2 {
	
	public static void main(String[] args) {
//		de helper class aanroepen
		HelperClass helper = new HelperClass();
//		dit is de hoofd loop van mastermind2.0
		while(helper.contPlaying) {
			helper.reset();
			helper.intro();
			helper.checkPlayers();
			if (helper.players == 1) {
				helper.secretCode = helper.randomSecretCode();
			}else {
				helper.twoPlayers();
				helper.spacing();
				}
			helper.guessCode();
			if (!helper.won) {
				helper.say("Je hebt verloren :(");
			}
		}	
		helper.inputReader.close();
		System.exit(0);
		}
	}