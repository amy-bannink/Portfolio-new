package mastermind2;

import java.util.*;

public class HelperClass {
	
	private String[] turnsFrames = { "        ", "        ", "        ", "        ", "        ", "        ", "        ", "        ", "        ", "        ", "        " },
			ansFrames = { "        ", "        ", "        ", "        ", "        ", "        ", "        ", "        ", "        ", "        ", "        " };
	private ArrayList<Character> inputCode = new ArrayList<Character>();
	private int turns = 0;
	private String codeUnformat = "";

	public Scanner inputReader = new Scanner(System.in);
	public int players = 0;
	public ArrayList<Character> secretCode = new ArrayList<Character>();
	public boolean contPlaying = true, won = false;

	
//	deze functie kijk naar de hoeveelheid spelers die er zijn ingetoetst
//	als dat niet 1 of 2 is dan word een error laten zien
	public void checkPlayers() {
		if (players == 1 || players == 2) {
		} else {
			say("error: voer 1 of 2 in");
			while (!inputReader.hasNextInt()) {
				inputReader.next();
				say("error: voer één cijfer in!");
			}
			players = inputReader.nextInt();
			checkPlayers();
		}
	}

//	deze functie zorgt er voor dat alle waardes het zelfde zijn als in het begin van het spel
	public void reset() {
		if (won == true) {
			won = false;
		}
		if (secretCode != null) {
			secretCode.clear();
		}
		if (inputCode != null) {
			inputCode.clear();
		}
		if (turns > 0) {
			turns = 0;
		}
		for (int k = 0; k < turnsFrames.length; k++) {
			turnsFrames[k] = "        ";
			ansFrames[k] = "        ";
		}
	}

//	deze functie laat de intro zien waar gevraagd word naar het aantal spelers
	public void intro() {
		sayLogo();
		say("Hoeveel mensen spelen er? (1/2)");
		while (!inputReader.hasNextInt()) {
			inputReader.next();
			say("error: voer een nummer in");
		}
		players = inputReader.nextInt();
		inputReader.nextLine();
	}
	
	//deze functie zorgt er voor dat als je met 2 spelers speelt je de geheime code moet invoeren
	public void twoPlayers() {
		say("Voer geheime code in");
		sayColors();
		// read and save input from the user
		codeUnformat = inputReader.nextLine();
		secretCode = stringToCharsList(codeUnformat, "twoPlayers");
	}

	//deze functie maakt van een string een char list
	public ArrayList<Character> stringToCharsList(String s, String header) {
		ArrayList<Character> tempList = new ArrayList<Character>();
		char[] array = new char[4];
		array = s.toCharArray();
		for (int i = 0; i < 4; i++) {
			if (Character.isDigit(array[i])) {
				say("error: voer alleen letters in");
				if (header == "twoPlayers") {
					twoPlayers();
					break;
				} else if (header == "guessCode") {
					turns -= 1;
					guessCode();
					break;
				}
			}
		}

		for (int i = 0; i < 4; i++) {
			tempList.add(array[i]);
		}
		return tempList;
	}

//	een functie die een random geheimecode maakt
	public ArrayList<Character> randomSecretCode() {
		Random rand = new Random();
		ArrayList<Character> tempList = new ArrayList<Character>();
		for (int i = 0; i < 4; i++) {
			int rnd = rand.nextInt(6);
			switch (rnd) {
			case 0:
				tempList.add('y');
				break;

			case 1:
				tempList.add('b');
				break;

			case 2:
				tempList.add('g');
				break;

			case 3:
				tempList.add('p');
				break;

			case 4:
				tempList.add('o');
				break;

			case 5:
				tempList.add('m');
				break;
			}

		}
		return tempList;
	}

//	ik vond system.out.println te lang dus heb ik het korter gemaakt voor mezelf
	public void say(String s) {
		System.out.println(s);
	}

//	een functie die de mogelijke keuzes laat zien
	public void sayColors() {
		System.out.println("" + "Kies uit: " + "y - yellow |" + "b - blue |" + "g - green |" + "p - purple |"
				+ "o - orange |" + "m - megenta |");
	}

	
	public void sayLogo() {
		System.out.println(""
				+ " ___      ___       __        ________  ___________  _______   _______   ___      ___   __    _____  ___   ________   \r\n"
				+ "|\"  \\    /\"  |     /\"\"\\      /\"       )(\"     _   \")/\"     \"| /\"      \\ |\"  \\    /\"  | |\" \\  (\\\"   \\|\"  \\ |\"      \"\\  \r\n"
				+ " \\   \\  //   |    /    \\    (:   \\___/  )__/  \\\\__/(: ______)|:        | \\   \\  //   | ||  | |.\\\\   \\    |(.  ___  :) \r\n"
				+ " /\\\\  \\/.    |   /' /\\  \\    \\___  \\       \\\\_ /    \\/    |  |_____/   ) /\\\\  \\/.    | |:  | |: \\.   \\\\  ||: \\   ) || \r\n"
				+ "|: \\.        |  //  __'  \\    __/  \\\\      |.  |    // ___)_  //      / |: \\.        | |.  | |.  \\    \\. |(| (___\\ || \r\n"
				+ "|.  \\    /:  | /   /  \\\\  \\  /\" \\   :)     \\:  |   (:      \"||:  __   \\ |.  \\    /:  | /\\  |\\|    \\    \\ ||:       :) \r\n"
				+ "|___|\\__/|___|(___/    \\___)(_______/       \\__|    \\_______)|__|  \\___)|___|\\__/|___|(__\\_|_)\\___|\\____\\)(________/  \r\n"
				+ "                                                                                                                      \r\n");
	}

	// dit is de interface die elke keer word gevuld en word laten zien
	public void frame() {
		System.out.println("" + " ---------------------- \r\n" + "|		        | \r\n" + "|  1. " + turnsFrames[1]
				+ " " + ansFrames[1] + " | \r\n" + "|  2. " + turnsFrames[2] + " " + ansFrames[2] + " | \r\n" + "|  3. "
				+ turnsFrames[3] + " " + ansFrames[3] + " | \r\n" + "|  4. " + turnsFrames[4] + " " + ansFrames[4]
				+ " | \r\n" + "|  5. " + turnsFrames[5] + " " + ansFrames[5] + " | \r\n" + "|  6. " + turnsFrames[6]
				+ " " + ansFrames[6] + " | \r\n" + "|  7. " + turnsFrames[7] + " " + ansFrames[7] + " | \r\n" + "|  8. "
				+ turnsFrames[8] + " " + ansFrames[8] + " | \r\n" + "|  9. " + turnsFrames[9] + " " + ansFrames[9]
				+ " | \r\n" + "| 10. " + turnsFrames[10] + " " + ansFrames[10] + " | \r\n" + "|		        | \r\n"
				+ " ---------------------- \r\n");
	}

	//ruimte bij de twee spelers modus zodat je moelijker kan afkijken
	public void spacing() {
		for (int i = 0; i < 10; i++) {
			say("");
		}
	}

//	deze functie checkt of de gok in het juiste format is gegeven
	public void checkGuess() {
		if (codeUnformat.equals("exit")) {
			System.exit(0);
		} else if (codeUnformat.length() != 4) {
			say("error: voer 4 letters in");
			codeUnformat = inputReader.nextLine();
			checkGuess();
		}
	}

	//hier word er gekeken of wat je hebt ingevoerd gelijk is aan de geheimecode
	public void guessCode() {
		for (int w = 0; w < 10; w++) {
			turns++;
			say("voer een gok in:");
			sayColors();
			codeUnformat = inputReader.nextLine();
			checkGuess();
			inputCode = stringToCharsList(codeUnformat, "guessCode");
			turnsFrames[turns] = codeUnformat.toString();
			//hier word gekeken of je hebt gewonnen
			if (secretCode.equals(inputCode)) {
				won = true;
				win();
				break;
			} else {
				compare();
			}
		}
	}

//	het bricht voor als je gewonnen hebt
	public void win() {
		say("je hebt gewonnen in " + turns + " beurten");
	}

	// de code om de template intevullen en te kijken of alles goed staat
	public void compare() {
		char[] temp = new char[4];
		char[] bu = setBackup(secretCode);
		
		for (int iv = 0; iv < secretCode.size(); iv++) {
			if (inputCode.get(iv).equals(secretCode.get(iv))) {
				temp[iv] = 'z'; // goed
				secretCode.set(iv, 'x');
				inputCode.set(iv, null);
			}
		}

		for (int ii = 0; ii < secretCode.size(); ii++) {
			for (int iii = 0; iii < secretCode.size(); iii++) {
				if (secretCode.get(iii) != 'x') {
					if (inputCode.get(ii) != null) {
						if (inputCode.get(ii) == secretCode.get(iii)) {
							temp[ii] = 'w';
							secretCode.set(iii, 'x');
							break;
						} else {
							temp[ii] = 'x';
						}
					}
				}
			}
		}

		secretCode = getBackup(bu);
		ansFrames[turns] = java.util.Arrays.toString(temp);
		frame();
	}

//	een backup maken
	private char[] setBackup(ArrayList<Character> list) {
		char[] backup = new char[4];
		for (int iv = 0; iv < secretCode.size(); iv++) {
			backup[iv] = secretCode.get(iv);
		}
		return backup;
	}

	//de backup terug zetten
	private ArrayList<Character> getBackup(char[] back) {
		ArrayList<Character> tempList = new ArrayList<Character>();
		for (int v = 0; v < back.length; v++) {
			tempList.add(back[v]);
		}
		return tempList;
	}

}